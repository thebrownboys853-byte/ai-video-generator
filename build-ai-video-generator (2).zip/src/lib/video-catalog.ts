/**
 * Mirage motion library + engine metadata.
 * Shared between server (render engine) and client (studio UI) — keep it
 * framework-free and dependency-free.
 */

export type StyleId =
  | "cinematic"
  | "hyperreal"
  | "anime"
  | "cyberpunk"
  | "analog16"
  | "noir"
  | "dreamcore"
  | "docu";

export interface StylePreset {
  id: StyleId;
  label: string;
  lens: string;
  swatch: string;
}

export const STYLE_PRESETS: StylePreset[] = [
  { id: "cinematic", label: "Cinematic", lens: "Anamorphic flare · teal-orange grade · 24fps blur", swatch: "from-amber-300 to-teal-400" },
  { id: "hyperreal", label: "Hyperreal", lens: "Photoreal · 85mm depth · natural light", swatch: "from-sky-300 to-blue-600" },
  { id: "anime", label: "Anime", lens: "Cel shading · bold linework · speed lines", swatch: "from-pink-400 to-violet-500" },
  { id: "cyberpunk", label: "Cyberpunk", lens: "Neon spill · chrome · perpetual rain", swatch: "from-fuchsia-500 to-cyan-400" },
  { id: "analog16", label: "Analog 16mm", lens: "Film grain · halation · matte box", swatch: "from-amber-200 to-stone-500" },
  { id: "noir", label: "Noir", lens: "Hard shadow · monochrome · smoke", swatch: "from-neutral-300 to-neutral-700" },
  { id: "dreamcore", label: "Dreamcore", lens: "Hazy pastels · floating camera", swatch: "from-rose-200 to-indigo-300" },
  { id: "docu", label: "Documentary", lens: "Handheld · available light · raw", swatch: "from-lime-300 to-emerald-600" },
];

export const ASPECT_RATIOS = ["16:9", "9:16", "1:1"] as const;
export type AspectRatio = (typeof ASPECT_RATIOS)[number];

export const DURATIONS = [4, 6, 8, 10] as const;

export const RENDER_STAGES: Array<{ until: number; label: string }> = [
  { until: 25, label: "Tokenizing prompt embeddings" },
  { until: 50, label: "Diffusing latent frames" },
  { until: 72, label: "Temporal upscaling pass" },
  { until: 90, label: "Applying film grade & grain" },
  { until: 101, label: "Muxing master file" },
];

export function stageForProgress(progress: number): string {
  for (const s of RENDER_STAGES) if (progress < s.until) return s.label;
  return "Muxing master file";
}

/** Credits charged per render — 1 credit per 2 seconds of footage. */
export function creditsForDuration(duration: number): number {
  return Math.max(1, Math.round(duration / 2));
}

export interface GenerationDTO {
  id: string;
  prompt: string;
  style: string;
  aspectRatio: string;
  duration: number;
  seed: number;
  status: "queued" | "rendering" | "completed" | "failed";
  progress: number;
  renderMs: number;
  videoUrl: string | null;
  posterUrl: string | null;
  category: string | null;
  createdAt: string;
  completedAt: string | null;
}

/* ------------------------------------------------------------------ */
/* Motion library: curated footage the MRG-2 demo engine renders with. */
/* ------------------------------------------------------------------ */

export type Category =
  | "mountains"
  | "ocean"
  | "neon"
  | "sky"
  | "ink"
  | "portrait"
  | "wildlife"
  | "food";

export interface CatalogEntry {
  id: string;
  category: Category;
  url: string;
  poster: string;
  caption: string;
  tags: string[];
}

export const CATALOG: CatalogEntry[] = [
  // --- mountains ---------------------------------------------------
  { id: "m1", category: "mountains", url: "https://videos.pexels.com/video-files/26081680/11929613_1920_1080_60fps.mp4", poster: "https://images.pexels.com/videos/26081680/4k-drone-4k-drone-video-4k-video-aerial-26081680.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "Drone dive over a glacial valley at dawn", tags: ["mountain", "forest", "valley", "aerial", "landscape", "nature", "drone", "pine", "meadow", "peak"] },
  { id: "m2", category: "mountains", url: "https://videos.pexels.com/video-files/26081666/11929584_1920_1080_60fps.mp4", poster: "https://images.pexels.com/videos/26081666/4k-drone-4k-drone-video-4k-video-aerial-26081666.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "A winding road through an endless pine forest", tags: ["road", "forest", "drive", "aerial", "pine", "highway", "journey"] },
  { id: "m3", category: "mountains", url: "https://videos.pexels.com/video-files/38369530/16294661_3840_2160_50fps.mp4", poster: "https://images.pexels.com/videos/38369530/adventure-aerial-view-alpine-landscape-cinematic-38369530.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "Storm clouds swallowing alpine peaks, 4K", tags: ["cloud", "storm", "alpine", "peak", "dramatic", "ridge", "mist"] },
  { id: "m4", category: "mountains", url: "https://videos.pexels.com/video-files/26081669/11929556_1920_1080_60fps.mp4", poster: "https://images.pexels.com/videos/26081669/4k-drone-4k-drone-video-4k-video-aerial-26081669.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "First snow settling on a silent hillside", tags: ["snow", "winter", "hillside", "cold", "frost", "white", "frozen"] },
  // --- ocean --------------------------------------------------------
  { id: "o1", category: "ocean", url: "https://videos.pexels.com/video-files/17205274/17205274-hd_1920_1080_24fps.mp4", poster: "https://images.pexels.com/videos/17205274/golden-sunset-storm-waves-slow-motion-17205274.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "Storm waves burnished gold by a dying sun", tags: ["ocean", "wave", "waves", "sea", "storm", "sunset", "gold", "swell", "surf"] },
  { id: "o2", category: "ocean", url: "https://videos.pexels.com/video-files/9722412/9722412-uhd_4096_1742_25fps.mp4", poster: "https://images.pexels.com/videos/9722412/pexels-photo-9722412.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "A single wave folding in ultra slow motion", tags: ["wave", "crest", "barrel", "surf", "slow motion", "water", "foam"] },
  { id: "o3", category: "ocean", url: "https://videos.pexels.com/video-files/28805527/12482396_1920_1080_24fps.mp4", poster: "https://images.pexels.com/videos/28805527/breaking-close-up-coast-impact-28805527.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "Violent swell at golden hour, anamorphic", tags: ["ocean", "coast", "impact", "spray", "dramatic", "break", "shore"] },
  { id: "o4", category: "ocean", url: "https://videos.pexels.com/video-files/37259189/15784119_1920_1080_24fps.mp4", poster: "https://images.pexels.com/videos/37259189/cinematic-crest-dark-deep-37259189.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "Deep-water crest breaking in slow motion", tags: ["deep", "dark", "crest", "tide", "sea", "current", "ocean"] },
  // --- neon city ----------------------------------------------------
  { id: "n1", category: "neon", url: "https://videos.pexels.com/video-files/34990368/14824169_1920_1080_60fps.mp4", poster: "https://images.pexels.com/videos/34990368/above-city-after-rain-city-rain-fog-34990368.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "Neo-Tokyo fog, neon spill on wet asphalt", tags: ["city", "neon", "fog", "rain", "cyberpunk", "tokyo", "skyline", "night"] },
  { id: "n2", category: "neon", url: "https://videos.pexels.com/video-files/855432/855432-hd_1840_1034_25fps.mp4", poster: "https://images.pexels.com/videos/855432/free-video-855432.jpg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "Taxi queue in midnight rain, sodium glow", tags: ["taxi", "street", "rain", "urban", "traffic", "night", "commute", "city"] },
  { id: "n3", category: "neon", url: "https://videos.pexels.com/video-files/3249516/3249516-hd_1840_1034_25fps.mp4", poster: "https://images.pexels.com/videos/3249516/free-video-3249516.jpg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "Two silhouettes, one umbrella, empty street", tags: ["umbrella", "silhouette", "street", "rain", "couple", "wet", "noir", "city"] },
  { id: "n4", category: "neon", url: "https://videos.pexels.com/video-files/32822471/13990568_3840_2160_24fps.mp4", poster: "https://images.pexels.com/videos/32822471/science-fiction-skayline-32822471.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "Cyberpunk skyline flyover, holographic haze", tags: ["cyberpunk", "futuristic", "skyline", "hologram", "sci-fi", "metropolis", "dystopia", "future"] },
  // --- sky / space --------------------------------------------------
  { id: "s1", category: "sky", url: "https://videos.pexels.com/video-files/13322952/13322952-uhd_3840_2160_30fps.mp4", poster: "https://images.pexels.com/videos/13322952/pexels-photo-13322952.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "Day-to-night timelapse over a sleeping city", tags: ["timelapse", "skyline", "dusk", "nightfall", "city", "sky"] },
  { id: "s2", category: "sky", url: "https://videos.pexels.com/video-files/6867012/6867012-hd_1920_1080_24fps.mp4", poster: "https://images.pexels.com/videos/6867012/camping-clouds-moon-night-6867012.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "Meteor shower above a desert campsite", tags: ["meteor", "shooting star", "camping", "moon", "night", "stars", "desert"] },
  { id: "s3", category: "sky", url: "https://videos.pexels.com/video-files/5004222/5004222-uhd_3840_2160_24fps.mp4", poster: "https://images.pexels.com/videos/5004222/mountains-night-sky-stars-timelapse-5004222.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "Milky Way wheeling above dark ridgelines", tags: ["milky way", "galaxy", "stars", "space", "cosmos", "universe", "night sky", "astro"] },
  { id: "s4", category: "sky", url: "https://videos.pexels.com/video-files/8644889/8644889-uhd_4096_2160_24fps.mp4", poster: "https://images.pexels.com/videos/8644889/pexels-photo-8644889.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "Star trails boiling over moonlit clouds", tags: ["star trails", "clouds", "moon", "aurora", "cosmos", "heavens", "sky"] },
  // --- abstract ink -------------------------------------------------
  { id: "a1", category: "ink", url: "https://videos.pexels.com/video-files/4112430/4112430-uhd_3840_2160_25fps.mp4", poster: "https://images.pexels.com/videos/4112430/pexels-photo-4112430.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "Colored smoke colliding in zero gravity", tags: ["smoke", "color", "abstract", "collision", "gradient", "vapor", "plume"] },
  { id: "a2", category: "ink", url: "https://videos.pexels.com/video-files/18333471/18333471-hd_1920_1080_30fps.mp4", poster: "https://images.pexels.com/videos/18333471/abstract-abstract-art-abstract-background-abstraction-18333471.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "Black ink blooming through clear water", tags: ["ink", "bloom", "water", "abstract", "fluid", "dark", "tendril"] },
  { id: "a3", category: "ink", url: "https://videos.pexels.com/video-files/18333375/18333375-hd_1920_1080_30fps.mp4", poster: "https://images.pexels.com/videos/18333375/abstract-acrylic-art-background-18333375.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "Acrylic galaxies folding into themselves", tags: ["acrylic", "paint", "swirl", "galaxy", "marble", "abstract", "fold"] },
  { id: "a4", category: "ink", url: "https://videos.pexels.com/video-files/7075988/7075988-uhd_4096_2160_30fps.mp4", poster: "https://images.pexels.com/videos/7075988/pexels-photo-7075988.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "Liquid color detonating against black", tags: ["liquid", "colorful", "explosion", "psychedelic", "dye", "mix", "ink"] },
  // --- portrait -----------------------------------------------------
  { id: "p1", category: "portrait", url: "https://videos.pexels.com/video-files/8111839/8111839-hd_1920_1080_30fps.mp4", poster: "https://images.pexels.com/videos/8111839/adult-art-band-beauty-8111839.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "A stranger lit only by a neon tube", tags: ["portrait", "neon", "person", "light", "face", "moody", "haze"] },
  { id: "p2", category: "portrait", url: "https://videos.pexels.com/video-files/6944579/6944579-uhd_3840_2160_25fps.mp4", poster: "https://images.pexels.com/videos/6944579/cyberpunk-neon-neon-art-neon-lights-6944579.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "Cyberpunk makeup test, magenta key light", tags: ["model", "makeup", "cyberpunk", "magenta", "fashion", "face", "woman"] },
  { id: "p3", category: "portrait", url: "https://videos.pexels.com/video-files/6835784/6835784-hd_1920_1080_25fps.mp4", poster: "https://images.pexels.com/videos/6835784/african-african-american-afro-american-6835784.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "Club dancer frozen mid-beat, pearls and sweat", tags: ["dancer", "club", "dance", "party", "movement", "dj", "night"] },
  { id: "p4", category: "portrait", url: "https://videos.pexels.com/video-files/7315373/7315373-hd_1920_1080_25fps.mp4", poster: "https://images.pexels.com/videos/7315373/adolescent-adult-art-beautiful-7315373.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "Gold glitter skin, macro slow push-in", tags: ["glitter", "skin", "gold", "macro", "beauty", "sparkle", "woman"] },
  // --- wildlife -----------------------------------------------------
  { id: "w1", category: "wildlife", url: "https://videos.pexels.com/video-files/19877526/19877526-uhd_3840_2160_60fps.mp4", poster: "https://images.pexels.com/videos/19877526/beautiful-brown-horse-chestnut-cinematic-19877526.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "Chestnut horse portrait, dust backlit at dusk", tags: ["horse", "animal", "portrait", "mane", "chestnut", "stallion", "equine"] },
  { id: "w2", category: "wildlife", url: "https://videos.pexels.com/video-files/39422444/16786147_1920_1080_100fps.mp4", poster: "https://images.pexels.com/videos/39422444/aarati-ancient-architecture-bagmati-39422444.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "Spotted deer alert in temple forest", tags: ["deer", "animal", "forest", "wildlife", "alert", "stag", "temple"] },
  { id: "w3", category: "wildlife", url: "https://videos.pexels.com/video-files/39422447/16786194_1920_1080_100fps.mp4", poster: "https://images.pexels.com/videos/39422447/aarati-ancient-architecture-bagmati-39422447.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "Yearling deer stepping through morning mist", tags: ["deer", "mist", "fawn", "wildlife", "calm", "graze", "wild"] },
  { id: "w4", category: "wildlife", url: "https://videos.pexels.com/video-files/38282587/16255944_3840_2160_60fps.mp4", poster: "https://images.pexels.com/videos/38282587/adventure-arizona-backpacker-backpacking-38282587.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "Mountain goat survey, 400mm compression", tags: ["goat", "mountain goat", "wildlife", "horns", "cliff", "alpine", "animal"] },
  // --- food / fire --------------------------------------------------
  { id: "f1", category: "food", url: "https://videos.pexels.com/video-files/2882090/2882090-uhd_3840_2160_24fps.mp4", poster: "https://images.pexels.com/videos/2882090/free-video-2882090.jpg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "Crab hitting the pan with a flame kiss", tags: ["cook", "kitchen", "crab", "seafood", "pan", "flame", "chef", "food"] },
  { id: "f2", category: "food", url: "https://videos.pexels.com/video-files/2894889/2894889-uhd_3840_2160_24fps.mp4", poster: "https://images.pexels.com/videos/2894889/free-video-2894889.jpg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "Wok hei — creamy sauce toss in slow motion", tags: ["wok", "sauce", "cooking", "creamy", "toss", "food", "steam"] },
  { id: "f3", category: "food", url: "https://videos.pexels.com/video-files/4042718/4042718-hd_1920_1080_24fps.mp4", poster: "https://images.pexels.com/videos/4042718/pexels-photo-4042718.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "Charcoal ignition, embers taking breath", tags: ["fire", "flame", "charcoal", "grill", "ember", "barbecue", "smoke", "burn"] },
  { id: "f4", category: "food", url: "https://videos.pexels.com/video-files/5037794/5037794-uhd_3840_2160_25fps.mp4", poster: "https://images.pexels.com/videos/5037794/chainesfastfoodfire-city-travel-colors-in-india-fastfood-5037794.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200", caption: "Street chef working live fire at midnight", tags: ["street food", "chef", "fire", "flame", "wok", "night market", "food", "sparks"] },
];

/* ------------------------------------------------------------------ */
/* Prompt → footage matching                                           */
/* ------------------------------------------------------------------ */

function djb2(input: string): number {
  let h = 5381;
  for (let i = 0; i < input.length; i++) {
    h = ((h << 5) + h + input.charCodeAt(i)) | 0;
  }
  return Math.abs(h);
}

/** Deterministically pick the catalog entry that best matches a prompt. */
export function pickVideoForPrompt(prompt: string, seed: number): CatalogEntry {
  const text = prompt.toLowerCase();
  const scored = CATALOG.map((entry) => {
    let score = 0;
    for (const tag of entry.tags) {
      if (text.includes(tag)) score += tag.length > 5 ? 3 : 2;
    }
    return { entry, score };
  });
  const best = Math.max(...scored.map((s) => s.score));
  const pool = best > 0 ? scored.filter((s) => s.score === best).map((s) => s.entry) : CATALOG;
  return pool[djb2(`${prompt}::${seed}`) % pool.length];
}

export function entryById(id: string): CatalogEntry | undefined {
  return CATALOG.find((e) => e.id === id);
}

/* ------------------------------------------------------------------ */
/* Curated content for landing + studio                                */
/* ------------------------------------------------------------------ */

export const SURPRISE_PROMPTS = [
  "A neon-drenched Tokyo alley in the rain, cinematic dolly forward",
  "Golden storm waves detonating against black volcanic rock",
  "A chestnut horse breathing slow in backlit dust, 400mm portrait",
  "Ink galaxies colliding underwater, ultramarine and gold",
  "A drone dive through a glacial valley at first light",
  "Cyberpunk skyline flyover through holographic smog",
  "A chef commanding live fire in a midnight street kitchen",
  "Star trails boiling over a moonlit mountain ridge",
  "A woman lit only by a neon tube, magenta haze, slow push-in",
  "Charcoal embers waking up in macro, drifting sparks",
  "Spotted deer stepping through temple mist at dawn",
  "Colored smoke blooming in zero gravity, 8K macro",
];

export const HERO_TICKER_PROMPTS = [
  "a lighthouse swallowing the storm",
  "chrome desert at 200mph",
  "two robots slow-dancing in the rain",
  "the last polaroid of earth",
  "a whale drifting through tokyo",
  "baroque ballroom, zero gravity",
  "deep-sea bioluminescent highway",
  "paper cranes over a burning city",
];

export interface ShowcaseSeed {
  catalogId: string;
  prompt: string;
  style: StyleId;
  aspectRatio: AspectRatio;
  duration: number;
  seed: number;
  hoursAgo: number;
}

/** Rows inserted the first time the queue is queried — instant history. */
export const SHOWCASE_SEEDS: ShowcaseSeed[] = [
  { catalogId: "o1", prompt: "Golden storm waves detonating against black volcanic rock, anamorphic, 24fps", style: "cinematic", aspectRatio: "16:9", duration: 8, seed: 88213407, hoursAgo: 2 },
  { catalogId: "n1", prompt: "Aerial drift over a rain-slicked neon city swallowed by fog", style: "cyberpunk", aspectRatio: "16:9", duration: 6, seed: 41099231, hoursAgo: 5 },
  { catalogId: "a4", prompt: "Liquid color detonating against infinite black, 8K macro", style: "dreamcore", aspectRatio: "1:1", duration: 6, seed: 77204410, hoursAgo: 9 },
  { catalogId: "w1", prompt: "Chestnut horse breathing slow in backlit dust, dusk, long-lens portrait", style: "cinematic", aspectRatio: "16:9", duration: 10, seed: 19035772, hoursAgo: 14 },
  { catalogId: "s3", prompt: "Milky Way wheeling above sleeping ridgelines, astrophotography timelapse", style: "hyperreal", aspectRatio: "16:9", duration: 8, seed: 55218890, hoursAgo: 22 },
  { catalogId: "p2", prompt: "Cyberpunk makeup test — magenta key light, macro, slow orbit", style: "cyberpunk", aspectRatio: "9:16", duration: 4, seed: 30087125, hoursAgo: 31 },
  { catalogId: "f3", prompt: "Charcoal ignition in macro — embers taking their first breath", style: "analog16", aspectRatio: "16:9", duration: 6, seed: 66120844, hoursAgo: 43 },
  { catalogId: "m3", prompt: "Storm clouds swallowing alpine peaks, 4K aerial, ominous", style: "docu", aspectRatio: "16:9", duration: 8, seed: 90331158, hoursAgo: 57 },
];
