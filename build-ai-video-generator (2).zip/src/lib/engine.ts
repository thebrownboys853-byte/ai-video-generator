import { db } from "@/db";
import { generations, type GenerationRow } from "@/db/schema";
import { eq } from "drizzle-orm";
import { entryById, pickVideoForPrompt, SHOWCASE_SEEDS } from "./video-catalog";

/** Time a job sits in the queue before compute picks it up. */
const QUEUE_MS = 1600;

interface AdvancePatch {
  status: "queued" | "rendering" | "completed";
  progress: number;
  videoUrl?: string;
  posterUrl?: string;
  category?: string;
  completedAt?: Date;
}

/**
 * Compute the next state of an in-flight job from wall-clock elapsed time.
 * Deterministic: the same row always yields the same state, so any request
 * can safely advance it (readable-worker pattern, no background daemon).
 */
export function computeAdvance(row: GenerationRow, now = Date.now()): AdvancePatch | null {
  if (row.status !== "queued" && row.status !== "rendering") return null;

  const startedAt = new Date(row.createdAt).getTime();
  const elapsed = now - startedAt;

  if (elapsed < QUEUE_MS) {
    if (row.status !== "queued" || row.progress !== 0) {
      return { status: "queued", progress: 0 };
    }
    return null;
  }

  const span = Math.max(row.renderMs - QUEUE_MS, 1);
  const p = (elapsed - QUEUE_MS) / span;

  if (p >= 1) {
    const entry = pickVideoForPrompt(row.prompt, row.seed);
    return {
      status: "completed",
      progress: 100,
      videoUrl: entry.url,
      posterUrl: entry.poster,
      category: entry.category,
      completedAt: new Date(),
    };
  }

  const progress = Math.min(99, Math.max(2, Math.floor(p * 100)));
  if (row.status !== "rendering" || row.progress !== progress) {
    return { status: "rendering", progress };
  }
  return null;
}

/** Persist any state changes for the given rows. Returns updated rows. */
export async function advanceRows(rows: GenerationRow[]): Promise<GenerationRow[]> {
  const now = Date.now();
  return Promise.all(
    rows.map(async (row) => {
      const patch = computeAdvance(row, now);
      if (!patch) return row;
      const [updated] = await db
        .update(generations)
        .set(patch)
        .where(eq(generations.id, row.id))
        .returning();
      return updated ?? row;
    }),
  );
}

/** Insert curated history the first time the queue is opened. */
export async function seedShowcaseIfEmpty(existingCount: number): Promise<void> {
  if (existingCount > 0) return;
  const now = Date.now();
  await db.insert(generations).values(
    SHOWCASE_SEEDS.map((s) => {
      const entry = entryById(s.catalogId);
      const createdAt = new Date(now - s.hoursAgo * 60 * 60 * 1000);
      return {
        prompt: s.prompt,
        style: s.style,
        aspectRatio: s.aspectRatio,
        duration: s.duration,
        seed: s.seed,
        status: "completed" as const,
        progress: 100,
        renderMs: 22000,
        videoUrl: entry?.url ?? null,
        posterUrl: entry?.poster ?? null,
        category: entry?.category ?? null,
        createdAt,
        completedAt: new Date(createdAt.getTime() + 22000),
      };
    }),
  );
}

/** Render time budget per job: longer clips take longer to diffuse. */
export function renderMsForDuration(duration: number): number {
  return 11000 + duration * 1800;
}
