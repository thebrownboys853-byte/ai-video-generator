import { Suspense } from "react";
import type { Metadata } from "next";
import StudioApp from "@/components/studio/studio-app";

export const metadata: Metadata = {
  title: "Studio — MIRAGE",
  description: "Direct and render AI video from a single prompt.",
};

export default function StudioPage() {
  return (
    <Suspense
      fallback={
        <div className="grid min-h-svh place-items-center bg-void">
          <p className="font-mono text-xs tracking-[0.3em] text-mist uppercase">
            Loading studio…
          </p>
        </div>
      }
    >
      <StudioApp />
    </Suspense>
  );
}
