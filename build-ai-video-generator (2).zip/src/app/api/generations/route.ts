import { NextResponse } from "next/server";
import { db } from "@/db";
import { generations } from "@/db/schema";
import { advanceRows, seedShowcaseIfEmpty } from "@/lib/engine";
import type { GenerationDTO } from "@/lib/video-catalog";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

function toDTO(row: typeof generations.$inferSelect): GenerationDTO {
  return {
    id: row.id,
    prompt: row.prompt,
    style: row.style,
    aspectRatio: row.aspectRatio,
    duration: row.duration,
    seed: row.seed,
    status: row.status as GenerationDTO["status"],
    progress: row.progress,
    renderMs: row.renderMs,
    videoUrl: row.videoUrl,
    posterUrl: row.posterUrl,
    category: row.category,
    createdAt: row.createdAt.toISOString(),
    completedAt: row.completedAt ? row.completedAt.toISOString() : null,
  };
}

export async function GET() {
  try {
    let rows = await db
      .select()
      .from(generations)
      .orderBy(desc(generations.createdAt))
      .limit(40);

    if (rows.length === 0) {
      await seedShowcaseIfEmpty(0);
      rows = await db
        .select()
        .from(generations)
        .orderBy(desc(generations.createdAt))
        .limit(40);
    }

    const advanced = await advanceRows(rows);
    const items = advanced
      .map(toDTO)
      .sort(
        (a, b) =>
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
      );

    return NextResponse.json({ items });
  } catch (error) {
    console.error("[generations] failed:", error);
    // Demo resilience: never hard-crash the studio on first boot.
    return NextResponse.json({ items: [], degraded: true });
  }
}
