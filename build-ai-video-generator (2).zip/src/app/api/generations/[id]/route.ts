import { NextResponse } from "next/server";
import { db } from "@/db";
import { generations } from "@/db/schema";
import { advanceRows } from "@/lib/engine";
import type { GenerationDTO } from "@/lib/video-catalog";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

function toDTO(row: typeof generations.$inferSelect): GenerationDTO {
  return {
    id: row.id,
    prompt: row.prompt,
    style: row.style,
    aspectRatio: row.aspectRatio,
    duration: row.duration,
    seed: row.seed,
    status: row.status as GenerationDTO["status"],
    progress: row.progress,
    renderMs: row.renderMs,
    videoUrl: row.videoUrl,
    posterUrl: row.posterUrl,
    category: row.category,
    createdAt: row.createdAt.toISOString(),
    completedAt: row.completedAt ? row.completedAt.toISOString() : null,
  };
}

type RouteContext = { params: Promise<{ id: string }> };

export async function GET(_request: Request, context: RouteContext) {
  const { id } = await context.params;
  try {
    const rows = await db.select().from(generations).where(eq(generations.id, id));
    if (rows.length === 0) {
      return NextResponse.json({ error: "Not found." }, { status: 404 });
    }
    const [advanced] = await advanceRows(rows);
    return NextResponse.json({ item: toDTO(advanced) });
  } catch (error) {
    console.error("[generation] failed:", error);
    return NextResponse.json({ error: "Lookup failed." }, { status: 500 });
  }
}

export async function DELETE(_request: Request, context: RouteContext) {
  const { id } = await context.params;
  try {
    await db.delete(generations).where(eq(generations.id, id));
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("[generation:delete] failed:", error);
    return NextResponse.json({ error: "Delete failed." }, { status: 500 });
  }
}
