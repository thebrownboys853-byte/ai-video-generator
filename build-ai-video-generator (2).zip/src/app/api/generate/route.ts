import { NextResponse } from "next/server";
import { db } from "@/db";
import { generations } from "@/db/schema";
import { renderMsForDuration } from "@/lib/engine";
import {
  ASPECT_RATIOS,
  DURATIONS,
  STYLE_PRESETS,
  type GenerationDTO,
} from "@/lib/video-catalog";
import { desc, inArray } from "drizzle-orm";

export const dynamic = "force-dynamic";

const STYLE_IDS = new Set(STYLE_PRESETS.map((s) => s.id));

function toDTO(row: typeof generations.$inferSelect): GenerationDTO {
  return {
    id: row.id,
    prompt: row.prompt,
    style: row.style,
    aspectRatio: row.aspectRatio,
    duration: row.duration,
    seed: row.seed,
    status: row.status as GenerationDTO["status"],
    progress: row.progress,
    renderMs: row.renderMs,
    videoUrl: row.videoUrl,
    posterUrl: row.posterUrl,
    category: row.category,
    createdAt: row.createdAt.toISOString(),
    completedAt: row.completedAt ? row.completedAt.toISOString() : null,
  };
}

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  const { prompt, style, aspectRatio, duration, seed } = (body ?? {}) as Record<
    string,
    unknown
  >;

  const cleanPrompt = typeof prompt === "string" ? prompt.trim() : "";
  if (cleanPrompt.length < 3 || cleanPrompt.length > 600) {
    return NextResponse.json(
      { error: "Prompt must be between 3 and 600 characters." },
      { status: 400 },
    );
  }

  const cleanStyle =
    typeof style === "string" && STYLE_IDS.has(style as never) ? style : "cinematic";
  const cleanRatio =
    typeof aspectRatio === "string" &&
    (ASPECT_RATIOS as readonly string[]).includes(aspectRatio)
      ? aspectRatio
      : "16:9";
  const cleanDuration =
    typeof duration === "number" && (DURATIONS as readonly number[]).includes(duration)
      ? duration
      : 6;
  const cleanSeed =
    typeof seed === "number" && Number.isFinite(seed)
      ? Math.abs(Math.floor(seed)) % 1_000_000_000
      : Math.floor(Math.random() * 1_000_000_000);

  try {
    // Saturate the render farm: at most 3 concurrent in-flight jobs.
    const active = await db
      .select({ id: generations.id })
      .from(generations)
      .where(inArray(generations.status, ["queued", "rendering"]));
    if (active.length >= 3) {
      return NextResponse.json(
        { error: "Render farm saturated — wait for a slot to free up." },
        { status: 429 },
      );
    }

    const [row] = await db
      .insert(generations)
      .values({
        prompt: cleanPrompt,
        style: cleanStyle,
        aspectRatio: cleanRatio,
        duration: cleanDuration,
        seed: cleanSeed,
        status: "queued",
        progress: 0,
        renderMs: renderMsForDuration(cleanDuration),
      })
      .returning();

    return NextResponse.json({ item: toDTO(row) }, { status: 201 });
  } catch (error) {
    console.error("[generate] failed:", error);
    return NextResponse.json(
      { error: "Engine unavailable. Is the database migrated?" },
      { status: 500 },
    );
  }
}

// Keep route.analysis happy in some bundlers that expect a GET export ordering helper
export async function GET() {
  const rows = await db
    .select({ id: generations.id })
    .from(generations)
    .orderBy(desc(generations.createdAt))
    .limit(1)
    .catch(() => []);
  return NextResponse.json({ ok: true, recent: rows.length });
}
