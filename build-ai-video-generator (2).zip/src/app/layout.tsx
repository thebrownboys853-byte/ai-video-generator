import type { Metadata } from "next";
import type { ReactNode } from "react";
import { JetBrains_Mono, Space_Grotesk, Unbounded } from "next/font/google";
import "./globals.css";

const display = Unbounded({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700", "800", "900"],
  variable: "--font-unbounded",
});

const sans = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-grotesk",
});

const mono = JetBrains_Mono({
  subsets: ["latin"],
  weight: ["400", "500", "700"],
  variable: "--font-jetmono",
});

export const metadata: Metadata = {
  title: "MIRAGE — Type it. Watch it move.",
  description:
    "MIRAGE is a text-to-video studio powered by the MRG-2 diffusion engine. Direct cinematic shots from a sentence: style lenses, camera control, seeds, native 4K.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${display.variable} ${sans.variable} ${mono.variable}`}>
      <body className="grain bg-void font-sans text-ink antialiased">{children}</body>
    </html>
  );
}
