import { Nav } from "@/components/site/nav";
import { Hero } from "@/components/site/hero";
import { Showcase } from "@/components/site/showcase";
import { Workflow } from "@/components/site/workflow";
import { Features } from "@/components/site/features";
import { CTA } from "@/components/site/cta";
import { Footer } from "@/components/site/footer";

export default function Home() {
  return (
    <main className="relative">
      <Nav />
      <Hero />
      <Showcase />
      <Workflow />
      <Features />
      <CTA />
      <Footer />
    </main>
  );
}
