import {
  integer,
  pgTable,
  text,
  timestamp,
  uuid,
  varchar,
} from "drizzle-orm/pg-core";

/**
 * A single text-to-video render job processed by the MRG-2 engine.
 * Rows move through: queued -> rendering -> completed.
 */
export const generations = pgTable("generations", {
  id: uuid("id").defaultRandom().primaryKey(),
  prompt: text("prompt").notNull(),
  style: varchar("style", { length: 40 }).notNull().default("cinematic"),
  aspectRatio: varchar("aspect_ratio", { length: 8 }).notNull().default("16:9"),
  duration: integer("duration").notNull().default(6),
  seed: integer("seed").notNull().default(0),
  status: varchar("status", { length: 16 }).notNull().default("queued"),
  progress: integer("progress").notNull().default(0),
  renderMs: integer("render_ms").notNull().default(20000),
  videoUrl: text("video_url"),
  posterUrl: text("poster_url"),
  category: varchar("category", { length: 40 }),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
  completedAt: timestamp("completed_at", { withTimezone: true }),
});

export type GenerationRow = typeof generations.$inferSelect;
export type NewGeneration = typeof generations.$inferInsert;
