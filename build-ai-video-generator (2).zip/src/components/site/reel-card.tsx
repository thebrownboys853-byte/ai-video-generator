"use client";

import { useEffect, useRef } from "react";
import type { CatalogEntry } from "@/lib/video-catalog";

/**
 * A living card from the latent feed. Plays while on screen, sleeps when it
 * leaves the viewport so sixteen reels never fight the GPU at once.
 */
export function ReelCard({ entry, index }: { entry: CatalogEntry; index: number }) {
  const ref = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const video = ref.current;
    if (!video) return;
    const io = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          video.play().catch(() => {});
        } else {
          video.pause();
        }
      },
      { threshold: 0.2 },
    );
    io.observe(video);
    return () => io.disconnect();
  }, []);

  return (
    <figure className="group relative w-[300px] shrink-0 overflow-hidden rounded-2xl border hairline bg-carbon transition-colors duration-500 hover:border-aura/40 md:w-[380px]">
      <div className="relative aspect-video overflow-hidden">
        <video
          ref={ref}
          src={entry.url}
          poster={entry.poster}
          muted
          loop
          playsInline
          preload="none"
          className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-[1.04]"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-void/85 via-transparent to-void/20" />
        <span className="glass absolute top-3 left-3 rounded-full px-2.5 py-1 font-mono text-[9px] tracking-[0.2em] text-aura uppercase">
          {entry.category} · mrg-2
        </span>
        <span className="absolute top-3 right-3 font-mono text-[9px] tracking-[0.2em] text-mist/70">
          {String(index + 1).padStart(3, "0")}
        </span>
      </div>
      <figcaption className="absolute inset-x-0 bottom-0 p-4">
        <p className="text-sm leading-snug text-ink/90">“{entry.caption}”</p>
      </figcaption>
    </figure>
  );
}
