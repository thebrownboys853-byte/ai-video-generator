"use client";

import type { CSSProperties } from "react";
import { motion } from "framer-motion";
import { CATALOG } from "@/lib/video-catalog";
import { ReelCard } from "./reel-card";

export function Showcase() {
  const rowA = CATALOG.slice(0, 8);
  const rowB = CATALOG.slice(8, 16);

  return (
    <section id="showcase" className="relative overflow-hidden py-24 md:py-36">
      <div className="mx-auto mb-14 flex max-w-7xl flex-col gap-6 px-5 md:flex-row md:items-end md:justify-between md:px-8">
        <div>
          <p className="mb-4 font-mono text-[10px] tracking-[0.3em] text-aura uppercase">
            01 / Latent feed
          </p>
          <h2 className="font-display text-3xl leading-tight font-black tracking-tight md:text-5xl">
            FRESH FROM
            <br />
            <span className="text-outline">THE LATENT SPACE</span>
          </h2>
        </div>
        <p className="max-w-sm text-sm leading-relaxed text-mist">
          Sixteen reels rendered in the last hour by directors who typed
          before they shot. Hover to pause the stream — every frame started
          life as one line of text.
        </p>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-80px" }}
        transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
        className="space-y-5"
      >
        <div className="marquee-hover overflow-hidden">
          <div className="marquee-track gap-5 pr-5" style={{ "--marquee-dur": "64s" } as CSSProperties}>
            {[...rowA, ...rowA].map((entry, i) => (
              <ReelCard key={`a-${entry.id}-${i}`} entry={entry} index={i % rowA.length} />
            ))}
          </div>
        </div>
        <div className="marquee-hover overflow-hidden">
          <div
            className="marquee-track reverse gap-5 pr-5"
            style={{ "--marquee-dur": "72s" } as CSSProperties}
          >
            {[...rowB, ...rowB].map((entry, i) => (
              <ReelCard key={`b-${entry.id}-${i}`} entry={entry} index={i % rowB.length} />
            ))}
          </div>
        </div>
      </motion.div>
    </section>
  );
}
