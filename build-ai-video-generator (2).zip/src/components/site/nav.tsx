"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Aperture, ArrowUpRight } from "lucide-react";
import { motion } from "framer-motion";

const LINKS = [
  { href: "#showcase", label: "Showcase" },
  { href: "#workflow", label: "Workflow" },
  { href: "#engine", label: "Engine" },
];

export function Nav() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.header
      initial={{ y: -32, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled ? "glass shadow-[0_12px_40px_-20px_rgba(0,0,0,0.9)]" : ""
      }`}
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 md:px-8">
        <Link href="/" className="group flex items-center gap-2.5">
          <span className="grid size-8 place-items-center rounded-md bg-aura text-void transition-transform duration-500 group-hover:rotate-90">
            <Aperture className="size-4.5" strokeWidth={2.4} />
          </span>
          <span className="font-display text-sm font-extrabold tracking-[0.22em] md:text-base">
            MIRAGE
          </span>
          <span className="mt-0.5 hidden font-mono text-[10px] tracking-widest text-dim sm:block">
            MRG-2
          </span>
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          {LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="font-mono text-[11px] tracking-[0.22em] text-mist uppercase transition-colors hover:text-aura"
            >
              {l.label}
            </a>
          ))}
        </nav>

        <Link
          href="/studio"
          className="group flex items-center gap-2 rounded-full border border-aura/40 bg-aura/10 px-4 py-2 font-mono text-[11px] tracking-[0.18em] text-aura uppercase transition-all duration-300 hover:bg-aura hover:text-void"
        >
          Open Studio
          <ArrowUpRight className="size-3.5 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
        </Link>
      </div>
    </motion.header>
  );
}
