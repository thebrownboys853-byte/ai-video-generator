"use client";

import { motion } from "framer-motion";
import { Dices, Film, Gauge, Terminal } from "lucide-react";
import { STYLE_PRESETS } from "@/lib/video-catalog";

const CAMERA_CHIPS = ["DOLLY IN", "ORBIT 180°", "CRANE UP", "HANDHELD", "PAN L→R", "MACRO PUSH", "FPV DIVE", "STATIC LOCK"];

const GRADE_CHIPS = [
  { k: "shot", v: "aerial, 400mm" },
  { k: "light", v: "dusk backlight" },
  { k: "grade", v: "teal-orange" },
  { k: "glass", v: "anamorphic" },
  { k: "motion", v: "slow push" },
  { k: "grain", v: "16mm halation" },
];

const cardAnim = (i: number) => ({
  initial: { opacity: 0, y: 28 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: "-60px" },
  transition: { delay: i * 0.08, duration: 0.8, ease: [0.16, 1, 0.3, 1] as const },
});

export function Features() {
  return (
    <section id="engine" className="relative py-24 md:py-36">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="mb-16 max-w-2xl">
          <p className="mb-4 font-mono text-[10px] tracking-[0.3em] text-aura uppercase">
            03 / The engine
          </p>
          <h2 className="font-display text-3xl leading-tight font-black tracking-tight md:text-5xl">
            MRG-2 UNDERSTANDS
            <br />
            <span className="text-outline">CINEMA, NOT CAPTIONS</span>
          </h2>
        </div>

        <div className="grid gap-5 lg:grid-cols-12">
          {/* Prompt-native direction */}
          <motion.div {...cardAnim(0)} className="relative overflow-hidden rounded-3xl border hairline bg-panel p-8 lg:col-span-7">
            <div className="flex items-center gap-3">
              <span className="grid size-10 place-items-center rounded-xl border hairline bg-raise text-aura">
                <Film className="size-5" strokeWidth={1.8} />
              </span>
              <h3 className="font-display text-lg font-extrabold">Prompt-native direction</h3>
            </div>
            <p className="mt-4 max-w-md text-sm leading-relaxed text-mist">
              One sentence decomposes into a full shot list — optics, lighting,
              grade, camera path and grain — compiled by the engine before a
              single frame is diffused.
            </p>
            <div className="mt-8 rounded-2xl border hairline bg-void/60 p-5">
              <p className="font-mono text-[11px] leading-relaxed text-mist">
                <span className="text-dim">render&gt;</span> a chestnut horse breathing
                slow in backlit dust, dusk, long-lens portrait
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                {GRADE_CHIPS.map((c) => (
                  <span key={c.k} className="flex items-center gap-1.5 rounded-full border hairline px-3 py-1 font-mono text-[10px]">
                    <span className="text-dim">{c.k}:</span>
                    <span className="text-aura">{c.v}</span>
                  </span>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Style lenses */}
          <motion.div {...cardAnim(1)} className="rounded-3xl border hairline bg-panel p-8 lg:col-span-5">
            <h3 className="font-display text-lg font-extrabold">8 style lenses</h3>
            <p className="mt-3 text-sm leading-relaxed text-mist">
              Optical personalities baked into the latent space — not LUTs
              slapped on after.
            </p>
            <div className="mt-6 grid grid-cols-2 gap-2.5">
              {STYLE_PRESETS.map((s) => (
                <div key={s.id} className="group flex items-center gap-2.5 rounded-xl border hairline bg-raise/50 px-3 py-2.5 transition-colors hover:border-aura/40">
                  <span className={`size-3.5 shrink-0 rounded-full bg-gradient-to-br ${s.swatch}`} />
                  <span className="truncate font-mono text-[10px] tracking-wide text-mist group-hover:text-ink">
                    {s.label}
                  </span>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Camera grammar */}
          <motion.div {...cardAnim(2)} className="rounded-3xl border hairline bg-panel p-8 lg:col-span-4">
            <h3 className="font-display text-lg font-extrabold">Camera grammar</h3>
            <p className="mt-3 text-sm leading-relaxed text-mist">
              Verb the camera. The engine tokenizes movement as first-class
              direction.
            </p>
            <div className="mt-6 flex flex-wrap gap-2">
              {CAMERA_CHIPS.map((c) => (
                <span key={c} className="rounded-full border hairline px-3 py-1.5 font-mono text-[10px] tracking-widest text-mist transition-colors hover:border-aura/40 hover:text-aura">
                  {c}
                </span>
              ))}
            </div>
          </motion.div>

          {/* Seed control */}
          <motion.div {...cardAnim(3)} className="relative overflow-hidden rounded-3xl border hairline bg-panel p-8 lg:col-span-4">
            <Dices className="absolute right-6 bottom-6 size-20 text-ink/[0.05]" />
            <h3 className="font-display text-lg font-extrabold">Seed-locked worlds</h3>
            <p className="mt-3 text-sm leading-relaxed text-mist">
              Same seed, same universe. Re-cut, re-grade, extend — your world
              stays put.
            </p>
            <p className="mt-8 font-mono text-4xl font-bold text-aura">88213407</p>
            <p className="mt-2 font-mono text-[10px] tracking-[0.2em] text-dim uppercase">
              current master seed
            </p>
          </motion.div>

          {/* API */}
          <motion.div {...cardAnim(4)} className="rounded-3xl border hairline bg-panel p-8 lg:col-span-4">
            <div className="flex items-center gap-3">
              <span className="grid size-10 place-items-center rounded-xl border hairline bg-raise text-aura">
                <Terminal className="size-5" strokeWidth={1.8} />
              </span>
              <h3 className="font-display text-lg font-extrabold">Render API</h3>
            </div>
            <div className="code-block mt-6 rounded-2xl border hairline bg-void/70 p-5">
              <p><span className="c">// POST /api/generate</span></p>
              <p>{"{"}</p>
              <p>&nbsp;&nbsp;<span className="k">"prompt"</span>: <span className="s">"storm waves, dusk"</span>,</p>
              <p>&nbsp;&nbsp;<span className="k">"style"</span>: <span className="s">"cinematic"</span>,</p>
              <p>&nbsp;&nbsp;<span className="k">"duration"</span>: 8,</p>
              <p>&nbsp;&nbsp;<span className="k">"seed"</span>: 88213407</p>
              <p>{"}"}</p>
            </div>
          </motion.div>

          {/* Throughput banner */}
          <motion.div {...cardAnim(5)} className="relative flex flex-col justify-between gap-8 overflow-hidden rounded-3xl border hairline bg-gradient-to-br from-raise to-panel p-8 lg:col-span-12 md:flex-row md:items-center">
            <div className="aurora absolute inset-0 opacity-60" />
            <div className="relative flex items-center gap-4">
              <span className="grid size-12 place-items-center rounded-2xl bg-aura text-void">
                <Gauge className="size-6" strokeWidth={2} />
              </span>
              <div>
                <p className="font-display text-xl font-extrabold md:text-2xl">128 GPU render farm</p>
                <p className="mt-1 font-mono text-[10px] tracking-[0.2em] text-mist uppercase">
                  4,096 latent frames in flight right now
                </p>
              </div>
            </div>
            <div className="relative grid grid-cols-3 gap-8">
              {[
                ["23s", "median"],
                ["99.98%", "uptime"],
                ["84K", "renders / day"],
              ].map(([v, l]) => (
                <div key={l}>
                  <p className="font-display text-2xl font-extrabold text-aura">{v}</p>
                  <p className="mt-1 font-mono text-[10px] tracking-[0.18em] text-dim uppercase">{l}</p>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
