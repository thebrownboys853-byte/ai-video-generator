"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";

export function CTA() {
  return (
    <section className="relative px-5 pb-24 md:px-8 md:pb-36">
      <motion.div
        initial={{ opacity: 0, scale: 0.97 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true, margin: "-80px" }}
        transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
        className="relative mx-auto max-w-7xl overflow-hidden rounded-[2.5rem] bg-aura px-6 py-16 text-void md:px-16 md:py-24"
      >
        <div
          className="pointer-events-none absolute inset-0 opacity-[0.08]"
          style={{
            backgroundImage:
              "radial-gradient(circle at 1px 1px, #060609 1px, transparent 0)",
            backgroundSize: "22px 22px",
          }}
        />
        <div className="relative flex flex-col gap-10 md:flex-row md:items-end md:justify-between">
          <div>
            <p className="mb-5 font-mono text-[10px] tracking-[0.3em] uppercase">
              No card · No waitlist
            </p>
            <h2 className="font-display text-4xl leading-[1.02] font-black tracking-tight md:text-6xl">
              YOUR FIRST
              <br />
              RENDER IS FREE.
            </h2>
          </div>
          <div className="flex flex-col items-start gap-5">
            <p className="max-w-xs text-sm leading-relaxed font-medium text-void/70">
              One prompt. Twenty seconds. A clip you&apos;ll want to show
              someone. That&apos;s the whole pitch.
            </p>
            <Link
              href="/studio"
              className="group inline-flex items-center gap-3 rounded-full bg-void px-7 py-4 font-mono text-xs font-bold tracking-[0.18em] text-aura uppercase transition-transform duration-300 hover:scale-105 active:scale-95"
            >
              Enter the studio
              <ArrowRight className="size-4 transition-transform duration-300 group-hover:translate-x-1" />
            </Link>
          </div>
        </div>
      </motion.div>
    </section>
  );
}
