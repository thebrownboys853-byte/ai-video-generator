"use client";

import { type CSSProperties, type FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { ArrowRight, Clapperboard, Sparkles, Wand2 } from "lucide-react";
import { CATALOG, HERO_TICKER_PROMPTS } from "@/lib/video-catalog";

const heroVideo = CATALOG.find((e) => e.id === "o1")!;

const rise = {
  hidden: { y: 42, opacity: 0 },
  show: (i: number) => ({
    y: 0,
    opacity: 1,
    transition: { delay: 0.12 * i, duration: 1, ease: [0.16, 1, 0.3, 1] as const },
  }),
};

export function Hero() {
  const router = useRouter();
  const [prompt, setPrompt] = useState("");

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const q = prompt.trim();
    router.push(q ? `/studio?prompt=${encodeURIComponent(q)}` : "/studio");
  };

  return (
    <section className="relative flex min-h-svh flex-col overflow-hidden">
      {/* Backdrop reel */}
      <div className="absolute inset-0">
        <video
          src={heroVideo.url}
          poster={heroVideo.poster}
          autoPlay
          muted
          loop
          playsInline
          className="h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-void/80 via-void/30 to-void" />
        <div className="aurora absolute inset-0 mix-blend-screen" />
      </div>

      {/* Content */}
      <div className="relative z-10 mx-auto flex w-full max-w-7xl flex-1 flex-col justify-center px-5 pt-36 pb-24 md:px-8">
        <motion.div
          variants={rise}
          custom={0}
          initial="hidden"
          animate="show"
          className="mb-8 flex flex-wrap items-center gap-3"
        >
          <span className="glass flex items-center gap-2 rounded-full px-3 py-1.5 font-mono text-[10px] tracking-[0.2em] text-aura uppercase">
            <span className="pulse-dot size-1.5 rounded-full bg-aura" />
            Engine online
          </span>
          <span className="glass rounded-full px-3 py-1.5 font-mono text-[10px] tracking-[0.2em] text-mist uppercase">
            MRG-2 · Build 2.4.1
          </span>
          <span className="glass hidden rounded-full px-3 py-1.5 font-mono text-[10px] tracking-[0.2em] text-mist uppercase sm:block">
            96 / 128 GPU rendering
          </span>
        </motion.div>

        <h1 className="font-display leading-[0.95] font-black tracking-tight">
          <motion.span
            variants={rise}
            custom={1}
            initial="hidden"
            animate="show"
            className="block text-[clamp(2.6rem,8.5vw,7.5rem)]"
          >
            TYPE IT.
          </motion.span>
          <motion.span
            variants={rise}
            custom={2}
            initial="hidden"
            animate="show"
            className="block text-[clamp(2.6rem,8.5vw,7.5rem)]"
          >
            WATCH IT{" "}
            <span className="text-outline-aura">MOVE.</span>
          </motion.span>
        </h1>

        <motion.p
          variants={rise}
          custom={3}
          initial="hidden"
          animate="show"
          className="mt-7 max-w-xl text-base leading-relaxed text-mist md:text-lg"
        >
          MIRAGE turns a sentence into directed, graded, camera-cut film. Pick a
          lens, lock a seed, hit render — the MRG-2 diffusion engine does the
          cinematography.
        </motion.p>

        {/* Prompt launcher */}
        <motion.form
          variants={rise}
          custom={4}
          initial="hidden"
          animate="show"
          onSubmit={submit}
          className="glass mt-10 flex max-w-2xl items-center gap-2 rounded-2xl p-2 shadow-[var(--shadow-panel)]"
        >
          <Wand2 className="ml-3 size-5 shrink-0 text-aura" strokeWidth={1.8} />
          <input
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="A lighthouse swallowing the storm, anamorphic…"
            className="min-w-0 flex-1 bg-transparent px-2 py-3 text-sm text-ink placeholder:text-dim focus:outline-none md:text-base"
            maxLength={600}
          />
          <button
            type="submit"
            className="group flex shrink-0 items-center gap-2 rounded-xl bg-aura px-4 py-3 font-mono text-[11px] font-bold tracking-[0.18em] text-void uppercase transition-transform duration-300 hover:scale-[1.03] active:scale-95 md:px-6"
          >
            <Clapperboard className="size-4" />
            <span className="hidden sm:inline">Generate</span>
            <ArrowRight className="size-3.5 transition-transform duration-300 group-hover:translate-x-0.5" />
          </button>
        </motion.form>

        {/* Stat strip */}
        <motion.dl
          variants={rise}
          custom={5}
          initial="hidden"
          animate="show"
          className="mt-14 grid max-w-2xl grid-cols-2 gap-6 sm:grid-cols-4"
        >
          {[
            ["9.2M", "frames rendered"],
            ["23s", "median render"],
            ["4K / 60", "native output"],
            ["8", "style lenses"],
          ].map(([v, l]) => (
            <div key={l} className="border-l hairline pl-4">
              <dt className="font-display text-lg font-bold text-ink md:text-xl">{v}</dt>
              <dd className="mt-1 font-mono text-[10px] tracking-[0.18em] text-dim uppercase">
                {l}
              </dd>
            </div>
          ))}
        </motion.dl>
      </div>

      {/* Prompt ticker */}
      <div className="marquee-hover relative z-10 border-t hairline py-4">
        <div className="marquee-track items-center gap-3" style={{ "--marquee-dur": "42s" } as CSSProperties}>
          {[...HERO_TICKER_PROMPTS, ...HERO_TICKER_PROMPTS].map((p, i) => (
            <button
              key={`${p}-${i}`}
              onClick={() => router.push(`/studio?prompt=${encodeURIComponent(p)}`)}
              className="group flex shrink-0 items-center gap-2 rounded-full border hairline px-4 py-1.5 font-mono text-[11px] text-mist transition-colors hover:border-aura/50 hover:text-aura"
            >
              <Sparkles className="size-3 text-dim transition-colors group-hover:text-aura" />
              {p}
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
