import Link from "next/link";
import { Aperture } from "lucide-react";

const COLS: Array<[string, string[]]> = [
  ["Product", ["Studio", "Latent feed", "Render API", "Changelog"]],
  ["Engine", ["MRG-2 overview", "Benchmarks", "Safety", "Status"]],
  ["Company", ["Manifesto", "Careers", "Press kit", "Contact"]],
];

export function Footer() {
  return (
    <footer className="relative overflow-hidden border-t hairline">
      <div className="mx-auto max-w-7xl px-5 pt-16 md:px-8">
        <div className="grid gap-12 pb-16 md:grid-cols-[1.2fr_repeat(3,1fr)]">
          <div>
            <Link href="/" className="flex items-center gap-2.5">
              <span className="grid size-8 place-items-center rounded-md bg-aura text-void">
                <Aperture className="size-4.5" strokeWidth={2.4} />
              </span>
              <span className="font-display text-base font-extrabold tracking-[0.22em]">MIRAGE</span>
            </Link>
            <p className="mt-5 max-w-xs text-sm leading-relaxed text-mist">
              A text-to-video studio for people who think in shots, not
              timelines. Directed by you, rendered by MRG-2.
            </p>
          </div>
          {COLS.map(([title, links]) => (
            <div key={title}>
              <p className="mb-5 font-mono text-[10px] tracking-[0.25em] text-dim uppercase">{title}</p>
              <ul className="space-y-3">
                {links.map((l) => (
                  <li key={l}>
                    <span className="cursor-pointer text-sm text-mist transition-colors hover:text-aura">{l}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="flex flex-col gap-3 border-t hairline py-6 font-mono text-[10px] tracking-[0.14em] text-dim uppercase md:flex-row md:items-center md:justify-between">
          <p>© 2026 Mirage Motion Systems</p>
          <p>Demo engine · renders via a curated motion library · footage by Pexels creators</p>
        </div>
      </div>

      <div
        aria-hidden
        className="pointer-events-none -mb-[1.5vw] text-center font-display text-[19vw] leading-none font-black text-ink/[0.045] select-none"
      >
        MIRAGE
      </div>
    </footer>
  );
}
