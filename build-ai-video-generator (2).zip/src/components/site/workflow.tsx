"use client";

import { motion } from "framer-motion";
import { MonitorPlay, SlidersHorizontal, Type } from "lucide-react";

const STEPS = [
  {
    n: "01",
    icon: Type,
    title: "DESCRIBE",
    body: "Write the shot like you're texting a cinematographer. Subject, light, movement, mood — the engine parses intent, not keywords.",
    meta: "natural language · 600 tokens",
  },
  {
    n: "02",
    icon: SlidersHorizontal,
    title: "DIRECT",
    body: "Choose a style lens, frame your aspect, set clip length and lock a seed. Every parameter is a dial on the camera, not a filter.",
    meta: "8 lenses · 3 frames · seed-locked",
  },
  {
    n: "03",
    icon: MonitorPlay,
    title: "RENDER & SHIP",
    body: "MRG-2 diffuses latent frames, upscales temporally, lays grain and grade — then hands you a master. Download or re-cut with the same seed.",
    meta: "~23s median · 4K master",
  },
];

export function Workflow() {
  return (
    <section id="workflow" className="relative border-y hairline bg-carbon/40 py-24 md:py-36">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="mb-16 flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
          <div>
            <p className="mb-4 font-mono text-[10px] tracking-[0.3em] text-aura uppercase">
              02 / Workflow
            </p>
            <h2 className="font-display text-3xl leading-tight font-black tracking-tight md:text-5xl">
              THREE LINES OF DIALOGUE
              <br />
              <span className="text-outline">BETWEEN YOU AND A FILM</span>
            </h2>
          </div>
        </div>

        <div className="grid gap-5 md:grid-cols-3">
          {STEPS.map((step, i) => (
            <motion.article
              key={step.n}
              initial={{ opacity: 0, y: 32 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ delay: i * 0.12, duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
              className="group relative overflow-hidden rounded-3xl border hairline bg-panel p-8 transition-colors duration-500 hover:border-aura/30"
            >
              <div className="pointer-events-none absolute -top-16 -right-10 font-display text-[9rem] font-black text-ink/[0.04] transition-colors duration-500 group-hover:text-aura/[0.07]">
                {step.n}
              </div>
              <div className="relative">
                <div className="mb-10 flex items-center justify-between">
                  <span className="grid size-11 place-items-center rounded-xl border hairline bg-raise text-aura">
                    <step.icon className="size-5" strokeWidth={1.8} />
                  </span>
                  <span className="font-mono text-[10px] tracking-[0.25em] text-dim">{step.n}</span>
                </div>
                <h3 className="font-display text-xl font-extrabold tracking-wide">{step.title}</h3>
                <p className="mt-4 text-sm leading-relaxed text-mist">{step.body}</p>
                <p className="mt-8 border-t hairline pt-4 font-mono text-[10px] tracking-[0.18em] text-dim uppercase">
                  {step.meta}
                </p>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}
