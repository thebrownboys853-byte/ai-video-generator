"use client";

import {
  type FormEvent,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import {
  Aperture,
  ChevronLeft,
  Clapperboard,
  Dices,
  Download,
  Expand,
  Loader2,
  RefreshCw,
  Sparkles,
  Trash2,
  Wand2,
  X,
  Zap,
} from "lucide-react";
import {
  ASPECT_RATIOS,
  DURATIONS,
  STYLE_PRESETS,
  SURPRISE_PROMPTS,
  creditsForDuration,
  stageForProgress,
  type GenerationDTO,
} from "@/lib/video-catalog";

const CREDITS_KEY = "mirage:credits";
const START_CREDITS = 120;

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return "just now";
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}

function frameInner(ratio: string, base: string): string {
  if (ratio === "9:16") return `${base} aspect-[9/16] max-h-[320px] mx-auto`;
  if (ratio === "1:1") return `${base} aspect-square`;
  return `${base} aspect-video`;
}

/** Autoplay-on-viewport video for completed renders. */
function AutoVideo({ gen, className }: { gen: GenerationDTO; className?: string }) {
  const ref = useRef<HTMLVideoElement>(null);
  useEffect(() => {
    const v = ref.current;
    if (!v) return;
    const io = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) v.play().catch(() => {});
        else v.pause();
      },
      { threshold: 0.25 },
    );
    io.observe(v);
    return () => io.disconnect();
  }, []);
  return (
    <video
      ref={ref}
      src={gen.videoUrl ?? undefined}
      poster={gen.posterUrl ?? undefined}
      muted
      loop
      playsInline
      preload="metadata"
      className={className}
    />
  );
}

export default function StudioApp() {
  const searchParams = useSearchParams();

  const [items, setItems] = useState<GenerationDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [degraded, setDegraded] = useState(false);

  const [prompt, setPrompt] = useState("");
  const [style, setStyle] = useState("cinematic");
  const [ratio, setRatio] = useState<string>("16:9");
  const [duration, setDuration] = useState<number>(6);
  const [seed, setSeed] = useState<number | null>(null);

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [active, setActive] = useState<GenerationDTO | null>(null);
  const [credits, setCredits] = useState(START_CREDITS);
  const prefilled = useRef(false);

  /* ------- credits persistence ------- */
  useEffect(() => {
    try {
      const v = localStorage.getItem(CREDITS_KEY);
      if (v !== null) setCredits(Math.max(0, parseInt(v, 10) || 0));
    } catch {}
  }, []);

  const spend = useCallback((n: number) => {
    setCredits((c) => {
      const next = Math.max(0, c - n);
      try {
        localStorage.setItem(CREDITS_KEY, String(next));
      } catch {}
      return next;
    });
  }, []);

  /* ------- prefill from landing prompt bar ------- */
  useEffect(() => {
    if (prefilled.current) return;
    const q = searchParams.get("prompt");
    if (q) {
      setPrompt(q.slice(0, 600));
      prefilled.current = true;
    }
  }, [searchParams]);

  /* ------- queue polling ------- */
  const refresh = useCallback(async () => {
    try {
      const res = await fetch("/api/generations", { cache: "no-store" });
      const data = (await res.json()) as { items?: GenerationDTO[]; degraded?: boolean };
      setItems(data.items ?? []);
      setDegraded(Boolean(data.degraded));
    } catch {
      setDegraded(true);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const hasActive = useMemo(
    () => items.some((i) => i.status === "queued" || i.status === "rendering"),
    [items],
  );

  useEffect(() => {
    const t = setInterval(refresh, hasActive ? 1500 : 7000);
    return () => clearInterval(t);
  }, [refresh, hasActive]);

  /* keep lightbox in sync with the live queue */
  useEffect(() => {
    setActive((current) => {
      if (!current) return null;
      return items.find((i) => i.id === current.id) ?? null;
    });
  }, [items]);

  /* ------- actions ------- */
  const cost = creditsForDuration(duration);

  const submit = async (e?: FormEvent) => {
    e?.preventDefault();
    if (prompt.trim().length < 3 || submitting) return;
    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: prompt.trim(),
          style,
          aspectRatio: ratio,
          duration,
          ...(seed !== null ? { seed } : {}),
        }),
      });
      const data = (await res.json()) as { error?: string };
      if (!res.ok) {
        setError(data.error ?? "Render failed to start.");
      } else {
        spend(cost);
        setPrompt("");
        setSeed(null);
        await refresh();
      }
    } catch {
      setError("Network error — engine unreachable.");
    } finally {
      setSubmitting(false);
    }
  };

  const remove = async (id: string) => {
    setItems((list) => list.filter((i) => i.id !== id));
    if (active?.id === id) setActive(null);
    try {
      await fetch(`/api/generations/${id}`, { method: "DELETE" });
    } catch {}
  };

  const reuse = (gen: GenerationDTO) => {
    setPrompt(gen.prompt);
    setStyle(gen.style);
    setRatio(gen.aspectRatio);
    setDuration(gen.duration);
    setSeed(gen.seed);
    setActive(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const surprise = () => {
    setPrompt(SURPRISE_PROMPTS[Math.floor(Math.random() * SURPRISE_PROMPTS.length)]);
  };

  const activeCount = items.filter(
    (i) => i.status === "queued" || i.status === "rendering",
  ).length;

  return (
    <div className="min-h-svh">
      {/* ---------- top bar ---------- */}
      <header className="glass sticky top-0 z-40 border-b hairline">
        <div className="mx-auto flex h-16 max-w-[1600px] items-center justify-between gap-4 px-5 md:px-8">
          <div className="flex items-center gap-4">
            <Link
              href="/"
              className="group flex items-center gap-1.5 font-mono text-[11px] tracking-[0.18em] text-mist uppercase transition-colors hover:text-aura"
            >
              <ChevronLeft className="size-4 transition-transform group-hover:-translate-x-0.5" />
              <span className="hidden sm:inline">Back</span>
            </Link>
            <span className="h-4 w-px bg-ink/15" />
            <div className="flex items-center gap-2.5">
              <span className="grid size-7 place-items-center rounded-md bg-aura text-void">
                <Aperture className="size-4" strokeWidth={2.4} />
              </span>
              <span className="font-display text-xs font-extrabold tracking-[0.22em]">
                MIRAGE <span className="text-dim">/ STUDIO</span>
              </span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className="hidden items-center gap-2 rounded-full border hairline px-3 py-1.5 font-mono text-[10px] tracking-[0.18em] text-mist uppercase sm:flex">
              <span className="pulse-dot size-1.5 rounded-full bg-aura" />
              MRG-2 online
            </span>
            <span className="flex items-center gap-1.5 rounded-full border border-aura/40 bg-aura/10 px-3 py-1.5 font-mono text-[10px] tracking-[0.14em] text-aura uppercase">
              <Zap className="size-3" />
              {credits} credits
            </span>
          </div>
        </div>
      </header>

      {degraded && (
        <div className="border-b border-flare/30 bg-flare/10 px-5 py-2.5 text-center font-mono text-[11px] tracking-[0.14em] text-flare uppercase">
          Engine warming up — database not reachable yet
        </div>
      )}

      {/* ---------- main ---------- */}
      <main className="mx-auto grid max-w-[1600px] gap-8 px-5 py-8 md:px-8 lg:grid-cols-[420px_1fr] lg:py-12">
        {/* ---------- composer ---------- */}
        <motion.section
          initial={{ opacity: 0, x: -24 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="lg:sticky lg:top-24 lg:self-start"
        >
          <form onSubmit={submit} className="rounded-3xl border hairline bg-panel p-6 md:p-7">
            {/* prompt */}
            <div className="mb-2 flex items-center justify-between">
              <label className="font-mono text-[10px] tracking-[0.25em] text-dim uppercase">
                Prompt
              </label>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={surprise}
                  className="flex items-center gap-1.5 font-mono text-[10px] tracking-[0.14em] text-mist uppercase transition-colors hover:text-aura"
                >
                  <Dices className="size-3.5" />
                  Surprise me
                </button>
                <span className="font-mono text-[10px] text-dim">{prompt.length}/600</span>
              </div>
            </div>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value.slice(0, 600))}
              rows={5}
              placeholder="Describe the shot — subject, light, camera, mood…"
              className="w-full resize-none rounded-2xl border hairline bg-void/60 p-4 text-sm leading-relaxed text-ink placeholder:text-dim focus:border-aura/50 focus:outline-none"
            />

            {/* style lenses */}
            <p className="mt-6 mb-3 font-mono text-[10px] tracking-[0.25em] text-dim uppercase">
              Style lens
            </p>
            <div className="grid grid-cols-2 gap-2">
              {STYLE_PRESETS.map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => setStyle(s.id)}
                  title={s.lens}
                  className={`flex items-center gap-2.5 rounded-xl border px-3 py-2.5 text-left transition-all duration-300 ${
                    style === s.id
                      ? "border-aura/60 bg-aura/10 text-ink"
                      : "hairline bg-raise/40 text-mist hover:text-ink"
                  }`}
                >
                  <span className={`size-3 shrink-0 rounded-full bg-gradient-to-br ${s.swatch}`} />
                  <span className="truncate text-xs font-medium">{s.label}</span>
                </button>
              ))}
            </div>

            {/* frame + length */}
            <div className="mt-6 grid grid-cols-2 gap-5">
              <div>
                <p className="mb-3 font-mono text-[10px] tracking-[0.25em] text-dim uppercase">Frame</p>
                <div className="flex gap-2">
                  {ASPECT_RATIOS.map((r) => (
                    <button
                      key={r}
                      type="button"
                      onClick={() => setRatio(r)}
                      className={`flex flex-1 flex-col items-center gap-1.5 rounded-xl border py-2.5 transition-all ${
                        ratio === r
                          ? "border-aura/60 bg-aura/10 text-ink"
                          : "hairline bg-raise/40 text-mist hover:text-ink"
                      }`}
                    >
                      <span
                        className={`border-2 border-current ${
                          r === "16:9" ? "h-3.5 w-6" : r === "9:16" ? "h-5 w-3" : "h-4 w-4"
                        }`}
                      />
                      <span className="font-mono text-[9px] tracking-widest">{r}</span>
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <p className="mb-3 font-mono text-[10px] tracking-[0.25em] text-dim uppercase">Length</p>
                <div className="flex gap-2">
                  {DURATIONS.map((d) => (
                    <button
                      key={d}
                      type="button"
                      onClick={() => setDuration(d)}
                      className={`flex-1 rounded-xl border py-3 font-mono text-[11px] transition-all ${
                        duration === d
                          ? "border-aura/60 bg-aura/10 text-ink"
                          : "hairline bg-raise/40 text-mist hover:text-ink"
                      }`}
                    >
                      {d}s
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* seed */}
            <div className="mt-6">
              <p className="mb-3 font-mono text-[10px] tracking-[0.25em] text-dim uppercase">
                Seed <span className="text-dim/60">(optional)</span>
              </p>
              <div className="flex items-center gap-2">
                <input
                  value={seed ?? ""}
                  onChange={(e) => {
                    const v = e.target.value.replace(/\D/g, "");
                    setSeed(v ? parseInt(v.slice(0, 9), 10) : null);
                  }}
                  placeholder="random"
                  inputMode="numeric"
                  className="min-w-0 flex-1 rounded-xl border hairline bg-void/60 px-4 py-2.5 font-mono text-sm text-ink placeholder:text-dim focus:border-aura/50 focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => setSeed(Math.floor(Math.random() * 1_000_000_000))}
                  className="grid size-10 place-items-center rounded-xl border hairline bg-raise/40 text-mist transition-colors hover:border-aura/50 hover:text-aura"
                  aria-label="Randomize seed"
                >
                  <Dices className="size-4" />
                </button>
                {seed !== null && (
                  <button
                    type="button"
                    onClick={() => setSeed(null)}
                    className="grid size-10 place-items-center rounded-xl border hairline bg-raise/40 text-mist transition-colors hover:text-flare"
                    aria-label="Clear seed"
                  >
                    <X className="size-4" />
                  </button>
                )}
              </div>
            </div>

            {/* submit */}
            {error && (
              <p className="mt-5 rounded-xl border border-flare/40 bg-flare/10 px-4 py-2.5 font-mono text-[11px] text-flare">
                {error}
              </p>
            )}
            <button
              type="submit"
              disabled={prompt.trim().length < 3 || submitting}
              className="group mt-7 flex w-full items-center justify-center gap-3 rounded-2xl bg-aura py-4 font-mono text-xs font-bold tracking-[0.2em] text-void uppercase transition-all duration-300 hover:shadow-[0_0_50px_rgba(205,244,90,0.35)] disabled:cursor-not-allowed disabled:opacity-30 disabled:hover:shadow-none"
            >
              {submitting ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <Clapperboard className="size-4" />
              )}
              {submitting ? "Queueing…" : "Generate video"}
              <span className="rounded-full bg-void/15 px-2 py-0.5 text-[10px]">
                {cost} cr
              </span>
            </button>
            <p className="mt-3 text-center font-mono text-[9px] tracking-[0.18em] text-dim uppercase">
              ~{Math.round((11000 + duration * 1800) / 1000)}s render · 4K master
            </p>
          </form>
        </motion.section>

        {/* ---------- queue ---------- */}
        <motion.section
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1, duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        >
          <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <h2 className="font-display text-lg font-extrabold tracking-wide">RENDER QUEUE</h2>
              {hasActive && (
                <RefreshCw className="size-3.5 animate-spin text-aura" />
              )}
            </div>
            <div className="flex items-center gap-2 font-mono text-[10px] tracking-[0.18em] uppercase">
              <span className="rounded-full border hairline px-3 py-1.5 text-mist">
                {activeCount} active
              </span>
              <span className="rounded-full border hairline px-3 py-1.5 text-mist">
                {items.length - activeCount} done
              </span>
            </div>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="shimmer aspect-video rounded-3xl border hairline" />
              ))}
            </div>
          ) : items.length === 0 ? (
            <div className="grid place-items-center rounded-3xl border border-dashed hairline py-24 text-center">
              <div>
                <Clapperboard className="mx-auto mb-5 size-10 text-dim" strokeWidth={1.4} />
                <p className="font-display text-base font-bold">No renders yet</p>
                <p className="mt-2 max-w-xs text-sm text-mist">
                  Type a scene on the left and hit Generate — your first film is
                  ~20 seconds away.
                </p>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 items-start gap-4 sm:grid-cols-2">
              <AnimatePresence mode="popLayout">
                {items.map((gen) => (
                  <QueueCard
                    key={gen.id}
                    gen={gen}
                    onOpen={() => setActive(gen)}
                    onDelete={() => remove(gen.id)}
                  />
                ))}
              </AnimatePresence>
            </div>
          )}
        </motion.section>
      </main>

      {/* ---------- lightbox ---------- */}
      <AnimatePresence>
        {active && (
          <RenderModal
            gen={active}
            onClose={() => setActive(null)}
            onDelete={() => remove(active.id)}
            onReuse={() => reuse(active)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

/* ================================================================== */

function QueueCard({
  gen,
  onOpen,
  onDelete,
}: {
  gen: GenerationDTO;
  onOpen: () => void;
  onDelete: () => void;
}) {
  const inFlight = gen.status === "queued" || gen.status === "rendering";
  const eta = Math.max(
    1,
    Math.min(99, Math.ceil(((100 - gen.progress) / 100) * (gen.renderMs / 1000))),
  );

  return (
    <motion.article
      layout
      initial={{ opacity: 0, scale: 0.96 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
      className="group overflow-hidden rounded-3xl border hairline bg-panel transition-colors duration-500 hover:border-aura/30"
    >
      {inFlight ? (
        <div className={frameInner(gen.aspectRatio, "relative w-full overflow-hidden bg-void/70")}>
          <div className="render-disc absolute inset-[18%] opacity-60 spin-slow" />
          <div className="absolute inset-0 grid place-items-center">
            <div className="text-center">
              <p className="font-display text-4xl font-black text-aura tabular-nums">
                {gen.status === "queued" ? "···" : `${gen.progress}%`}
              </p>
              <p className="mt-3 flex items-center justify-center gap-2 font-mono text-[10px] tracking-[0.18em] text-mist uppercase">
                <Loader2 className="size-3 animate-spin text-aura" />
                {gen.status === "queued"
                  ? "Waiting for GPU slot"
                  : stageForProgress(gen.progress)}
              </p>
            </div>
          </div>
          <div className="absolute inset-x-0 bottom-0 h-1 bg-ink/5">
            <div
              className="h-full bg-aura transition-all duration-700 ease-linear"
              style={{ width: `${gen.progress}%` }}
            />
          </div>
          <span className="absolute top-3 right-3 font-mono text-[9px] tracking-[0.2em] text-mist/80 uppercase">
            eta 00:{String(eta).padStart(2, "0")}
          </span>
        </div>
      ) : (
        <button
          onClick={onOpen}
          className={frameInner(
            gen.aspectRatio,
            "relative block w-full cursor-pointer overflow-hidden bg-black",
          )}
        >
          <AutoVideo gen={gen} className="h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-void/70 via-transparent to-transparent opacity-60 transition-opacity duration-500 group-hover:opacity-30" />
          <span className="glass absolute top-3 right-3 grid size-8 place-items-center rounded-full text-ink opacity-0 transition-all duration-300 group-hover:opacity-100">
            <Expand className="size-3.5" />
          </span>
          <span className="glass absolute bottom-3 left-3 rounded-full px-2.5 py-1 font-mono text-[9px] tracking-[0.18em] text-aura uppercase">
            {gen.category ?? "mrg-2"} · master
          </span>
        </button>
      )}

      <div className="p-4">
        <p className="line-clamp-2 min-h-[2.5em] text-sm leading-snug text-ink/90">
          “{gen.prompt}”
        </p>
        <div className="mt-3 flex items-center justify-between gap-2">
          <div className="flex min-w-0 flex-wrap items-center gap-x-3 gap-y-1 font-mono text-[9px] tracking-[0.14em] text-dim uppercase">
            <span className="text-mist">{gen.style}</span>
            <span>{gen.aspectRatio}</span>
            <span>{gen.duration}s</span>
            <span title="seed">#{gen.seed.toString().slice(0, 8)}</span>
            <span>{timeAgo(gen.createdAt)}</span>
          </div>
          <button
            onClick={onDelete}
            aria-label="Delete render"
            className="grid size-8 shrink-0 place-items-center rounded-lg text-dim transition-colors hover:bg-flare/10 hover:text-flare"
          >
            <Trash2 className="size-3.5" />
          </button>
        </div>
      </div>
    </motion.article>
  );
}

/* ================================================================== */

function RenderModal({
  gen,
  onClose,
  onDelete,
  onReuse,
}: {
  gen: GenerationDTO;
  onClose: () => void;
  onDelete: () => void;
  onReuse: () => void;
}) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const inFlight = gen.status === "queued" || gen.status === "rendering";

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] grid place-items-center bg-void/85 p-4 backdrop-blur-md md:p-8"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.94, y: 24 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.96, y: 12 }}
        transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-4xl overflow-hidden rounded-3xl border hairline bg-panel shadow-[var(--shadow-panel)]"
      >
        <div className="flex items-center justify-between border-b hairline px-5 py-3.5">
          <p className="flex items-center gap-2 font-mono text-[10px] tracking-[0.22em] text-aura uppercase">
            <Sparkles className="size-3.5" />
            Master · seed #{gen.seed}
          </p>
          <button
            onClick={onClose}
            className="grid size-8 place-items-center rounded-lg text-mist transition-colors hover:bg-raise hover:text-ink"
            aria-label="Close"
          >
            <X className="size-4" />
          </button>
        </div>

        <div className="grid place-items-center bg-black">
          {inFlight ? (
            <div className="relative aspect-video w-full overflow-hidden">
              <div className="render-disc absolute inset-[15%] opacity-60 spin-slow" />
              <div className="absolute inset-0 grid place-items-center text-center">
                <div>
                  <p className="font-display text-5xl font-black text-aura tabular-nums">
                    {gen.progress}%
                  </p>
                  <p className="mt-4 font-mono text-[11px] tracking-[0.18em] text-mist uppercase">
                    {gen.status === "queued"
                      ? "Waiting for GPU slot"
                      : stageForProgress(gen.progress)}
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <video
              key={gen.id}
              src={gen.videoUrl ?? undefined}
              poster={gen.posterUrl ?? undefined}
              autoPlay
              loop
              controls
              playsInline
              className={`w-full bg-black object-contain ${
                gen.aspectRatio === "9:16"
                  ? "max-h-[65vh]"
                  : gen.aspectRatio === "1:1"
                    ? "max-h-[60vh]"
                    : "max-h-[60vh]"
              }`}
            />
          )}
        </div>

        <div className="px-5 py-5">
          <p className="text-base leading-relaxed text-ink">“{gen.prompt}”</p>
          <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1.5 font-mono text-[10px] tracking-[0.16em] text-dim uppercase">
            <span className="text-aura">{gen.style}</span>
            <span>{gen.aspectRatio}</span>
            <span>{gen.duration}s clip</span>
            <span>seed #{gen.seed}</span>
            <span>{timeAgo(gen.createdAt)}</span>
            <span>mrg-2 engine</span>
          </div>
          <div className="mt-5 flex flex-wrap items-center gap-2.5 border-t hairline pt-5">
            {!inFlight && gen.videoUrl && (
              <a
                href={gen.videoUrl}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-2 rounded-full bg-aura px-5 py-2.5 font-mono text-[11px] font-bold tracking-[0.16em] text-void uppercase transition-transform hover:scale-105 active:scale-95"
              >
                <Download className="size-3.5" />
                Download
              </a>
            )}
            <button
              onClick={onReuse}
              className="flex items-center gap-2 rounded-full border hairline px-5 py-2.5 font-mono text-[11px] tracking-[0.16em] text-mist uppercase transition-colors hover:border-aura/50 hover:text-aura"
            >
              <Wand2 className="size-3.5" />
              Re-cut with these settings
            </button>
            <button
              onClick={onDelete}
              className="ml-auto flex items-center gap-2 rounded-full border hairline px-5 py-2.5 font-mono text-[11px] tracking-[0.16em] text-dim uppercase transition-colors hover:border-flare/50 hover:text-flare"
            >
              <Trash2 className="size-3.5" />
              Delete
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
